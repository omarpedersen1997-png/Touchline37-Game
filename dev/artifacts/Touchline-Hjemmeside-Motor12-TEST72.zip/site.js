const motion = matchMedia('(prefers-reduced-motion: reduce)');

function startCountdown() {
  const output = [...document.querySelectorAll('[data-clock]')];
  const release = Date.parse(document.getElementById('launch-date')?.dateTime);
  if (!Number.isFinite(release) || output.length !== 4) return;
  const status = document.getElementById('launch-status');
  let timer;
  const update = () => {
    const remaining = Math.max(0, Math.ceil((release - Date.now()) / 1000));
    const values = [Math.floor(remaining / 86400), Math.floor(remaining / 3600) % 24, Math.floor(remaining / 60) % 60, remaining % 60];
    for (const [i, field] of output.entries()) {
      const next = String(values[i]).padStart(2, '0');
      if (field.textContent === next) continue;
      field.textContent = next;
    }
    if (!remaining) {
      const message = 'Det planlagte lanceringstidspunkt er nået.';
      if (status.textContent !== message) status.textContent = message;
      return;
    }
    if (!document.hidden) timer = setTimeout(update, 1000 - (Date.now() % 1000));
  };
  document.addEventListener('visibilitychange', () => { clearTimeout(timer); if (!document.hidden) update(); });
  update();
}

const slides = [
  {label:'SPIL SELV', title:'Find den frie mand.', text:'Styr boldholderen, læg en stikning, og følg løbet på minikortet. Når du mister bolden, kan du skifte forsvarer og tackle.', file:'arena', alt:'Åbent spil i Touchline med minikort, styrepude og kampur', action:'Prøv kampen', href:'/demo/play/index.html?demo=1'},
  {label:'DØDBOLD', title:'Over muren eller kort?', text:'Stil dig over bolden og læs muren. Kampen venter på dit spark. Du kan afslutte selv eller spille kort til en medspiller.', file:'frispark', alt:'Et frispark med fire forsvarere i muren og målet bag dem', action:'Prøv taktiktavlen', href:'#taktik'},
  {label:'KLUBHUSET', title:'Tag plads på bænken.', text:'Vælg Simulér kampen for at lade holdene spille. Justér formation og pres undervejs. En sæson har 15 kampe på vejen fra League 10 til League 1.', file:'club', alt:'Klubmenuen med Prøvelund BK, næste ligakamp og adgang til taktik og trup', action:'Åbn klubhuset', href:'/demo/play/index.html'},
];

function startDeck() {
  const panel = document.getElementById('game-panel');
  if (!panel) return;
  const tabs = [...document.querySelectorAll('[role=tab]')];
  const image = document.getElementById('game-image');
  const action = document.getElementById('game-action');
  const largeImage = document.getElementById('game-large');
  const status = document.getElementById('deck-status');
  let active = 0;
  const story = document.getElementById('game-title').parentElement;
  let imageMotion, storyMotion;
  const stopMotion = () => { imageMotion?.cancel(); storyMotion?.cancel(); };
  motion.addEventListener('change',stopMotion);
  let start;
  const wrap = value => (value + slides.length) % slides.length;
  function select(value, focus = false) {
    const next = wrap(value);
    if (next === active) { if (focus) tabs[next].focus(); return; }
    const direction = value === active - 1 || value === active + 2 ? -1 : 1;
    active = next;
    const slide = slides[active];
    const base = '/assets/motor12/' + slide.file;
    image.src = base + '.webp';
    image.alt = slide.alt;
    largeImage.href = base + '.webp';
    largeImage.setAttribute('aria-label', 'Se spilbilledet i fuld størrelse · ' + tabs[active].textContent);
    for (const [name, content] of [['label', slide.label], ['title', slide.title], ['copy', slide.text]]) {
      document.getElementById('game-' + name).textContent = content;
    }
    action.textContent = slide.action;
    action.href = slide.href;
    panel.setAttribute('aria-labelledby', tabs[active].id);
    tabs.forEach((tab, i) => {
      tab.setAttribute('aria-selected', String(i === active));
      tab.tabIndex = i === active ? 0 : -1;
    });
    if (focus) tabs[active].focus();
    else status.textContent = tabs[active].textContent;
    stopMotion();
    if (!motion.matches) {
      const timing = {duration:290, easing:'cubic-bezier(.2,.75,.26,1)'};
      storyMotion = story?.animate?.([{transform:'translateY(8px)',opacity:.76},{transform:'none',opacity:1}],timing);
      const reveal = () => {
        if (active !== next || motion.matches || document.hidden) return;
        imageMotion?.cancel();
        imageMotion = image.animate?.([{transform:'translateX('+direction*8+'px)',opacity:.84},{transform:'none',opacity:1}],timing);
      };
      if (image.decode) image.decode().then(reveal, () => {});
      else reveal();
    }
  }
  tabs.forEach((tab, i) => tab.addEventListener('click', () => select(i)));
  document.querySelectorAll('[data-step]').forEach(button => button.addEventListener('click', () => select(active + Number(button.dataset.step))));
  panel.closest('.deck').addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    const onTab = tabs.includes(event.target);
    if (!onTab && event.target !== panel) return;
    const steps = {ArrowRight:active+1, ArrowLeft:active-1, Home:0, End:slides.length-1};
    if (!(event.key in steps)) return;
    event.preventDefault();
    select(steps[event.key], onTab);
  });
  panel.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' || event.target.closest('a,button')) return;
    start = {id:event.pointerId,x:event.clientX,y:event.clientY};
  });
  panel.addEventListener('pointercancel', () => { start = undefined; });
  panel.addEventListener('pointerup', event => {
    if (!start || start.id !== event.pointerId) return;
    const dx = event.clientX - start.x, dy = event.clientY - start.y;
    start = undefined;
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4) select(active + (dx < 0 ? 1 : -1));
  });
}

const tactics = {
  balanced:{title:'Hold kæderne samlet',text:'Skab sikre vinkler i opspillet, og hold afstandene korte, når bolden mistes.',lines:[22,39,55],width:1},
  press:{title:'Pres boldholderen tidligt',text:'Skub holdet frem i en samlet blok, så der er støtte bag det første pres. Der bliver mere plads bag bagkæden.',lines:[36,51,65],width:.63},
  wide:{title:'Gør banen stor med bolden',text:'Træk de brede spillere ud mod linjen, og skab plads til en aflevering gennem midten.',lines:[24,44,63],width:1.25},
};
const formation = [
  [1,10,50],[2,22,23],[4,22,41],[5,22,59],[3,22,77],
  [6,39,31],[8,39,50],[10,39,69],[7,55,24],[9,55,50],[11,55,76],
];

// Index the numbered players in the current formation. The press sequence
// starts with an opponent, then shows where our forwards win and use the ball.
const patterns = {
  balanced:{players:[5,6,9],title:'Opspil gennem 6, 8 og 9'},
  press:{players:[13,9,8],title:'9 bryder boldbanen og spiller 7 fri'},
  wide:{players:[6,7,10],title:'8 og 10 finder 11 på kanten'},
};

function startTactics() {
  const board = document.getElementById('pitch');
  if (!board) return;
  const area = document.getElementById('players');
  const ball = document.getElementById('board-ball');
  const keys = [...document.querySelectorAll('[data-tactic]')];
  const figures = [false,true].flatMap(away => formation.map(([number]) => {
    const node = document.createElement('span');
    node.className = away ? 'player away' : 'player';
    node.textContent = number;
    area.append(node);
    return node;
  }));
  const lanes = document.getElementById('passing-lanes');
  const caption = document.getElementById('route-caption');
  const replay = document.getElementById('replay-tactic');
  let flight;
  let current = 'balanced';
  let visible = false;
  function render(size = board.getBoundingClientRect(), play = false) {
    flight?.cancel();
    const points = [];
    const setting = tactics[current];
    const at = (element, x, y) => {
      element.style.setProperty('--x', (x * .01 * size.width).toFixed(2));
      element.style.setProperty('--y', (y * .01 * size.height).toFixed(2));
    };
    for (const [i, [,x,y]] of formation.entries()) {
      const line = i < 5 ? 0 : i < 8 ? 1 : 2;
      const homeX = i === 0 ? x : setting.lines[line] + (i % 2 ? 1 : -1);
      at(figures[i],homeX,50+(y-50)*setting.width);
      points[i] = [homeX,50+(y-50)*setting.width];
      const pressure = current === 'press' && i > 0 ? 8 : 0;
      points[i+11] = [100-x+pressure,50+(y-50)*.96];
      at(figures[i+11],...points[i+11]);
    }
    const pattern = patterns[current];
    const route = pattern.players.map(i => points[i]);
    if (caption) caption.textContent = pattern.title;
    const positions = route.map(([x,y])=>[(x+.9)*size.width/100,(y+1.6)*size.height/100]);
    for (const [i,line] of Array.from(lanes?.children ?? []).entries()) {
      const [x,y] = positions[i], dx = positions[i+1][0]-x, dy = positions[i+1][1]-y;
      line.style.width = Math.hypot(dx,dy)+'px';
      line.style.transform = 'translate('+x+'px,'+y+'px) rotate('+Math.atan2(dy,dx)+'rad)';
    }
    const last = route[route.length-1];
    at(ball,last[0]+.9,last[1]+1.6);
    if (play && !motion.matches && !document.hidden && ball.animate) {
      const frames = positions.map(([x,y])=>({transform:'translate3d('+x+'px,'+y+'px,0) translate(-50%,-50%)'}));
      flight = ball.animate([frames[0],{...frames[0],offset:.15},{...frames[1],offset:.48},{...frames[1],offset:.59},frames[2]],
        {duration:1320,easing:'linear'});
    }
  }
  const setMotion = () => {
    board.classList.toggle('animated',visible && !motion.matches && !document.hidden);
    if (!visible || motion.matches || document.hidden) flight?.cancel();
  };
  if (replay) {
    replay.hidden = false;
    replay.addEventListener('click',()=>render(undefined,true));
  }
  if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
    visible = entries[0].isIntersecting;
    board.classList.toggle('on-screen',visible);
    setMotion();
  }).observe(board);
  motion.addEventListener('change',setMotion);
  document.addEventListener('visibilitychange',setMotion);
  function select(button) {
    const selected = button.dataset.tactic;
    if (selected === current) return;
    current = selected;
    const item = tactics[current];
    keys.forEach(key => key.setAttribute('aria-pressed',String(key === button)));
    document.getElementById('tactic-title').textContent = item.title;
    document.getElementById('tactic-copy').textContent = item.text;
    render(undefined,true);
  }
  for (const button of keys) {
    let touch;
    button.addEventListener('click', () => select(button));
    button.addEventListener('pointerdown', event => {
      if (event.pointerType === 'touch') touch = {id:event.pointerId,x:event.clientX,y:event.clientY};
    });
    button.addEventListener('pointercancel', () => { touch = undefined; });
    button.addEventListener('pointerup', event => {
      const point = touch;
      touch = undefined;
      if (event.pointerType === 'touch' && point?.id === event.pointerId &&
          Math.hypot(event.clientX - point.x, event.clientY - point.y) < 12 &&
          document.elementFromPoint(event.clientX,event.clientY)?.closest('button') === button) {
        select(button);
      }
    });
  }
  render();
  if ('ResizeObserver' in window) new ResizeObserver(entries => render(entries[0].contentRect)).observe(board);
  else window.addEventListener('resize',() => render());
}

function startImageViewer() {
  const dialog = document.getElementById('image-viewer');
  if (!dialog?.showModal) return;
  const photo = document.getElementById('viewer-image');
  const title = document.getElementById('viewer-title');
  let opener;
  for (const link of document.querySelectorAll('[data-open-image]')) {
    link.addEventListener('click',event=>{
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      const original = link.closest('figure').querySelector('img');
      event.preventDefault();
      photo.src = original.currentSrc || original.src;
      photo.alt = original.alt;
      title.textContent = link.id === 'game-large' ? document.getElementById('game-title').textContent : 'Frispark ved feltet';
      opener = link;
      dialog.showModal();
    });
  }
  dialog.addEventListener('click',event=>{ if (event.target===dialog) dialog.close(); });
  dialog.addEventListener('close',()=>opener?.focus());
}

startImageViewer();
startCountdown();
startDeck();
startTactics();
