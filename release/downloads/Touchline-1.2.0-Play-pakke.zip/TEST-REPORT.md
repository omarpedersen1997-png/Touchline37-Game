# Launch verification — 1.0.1

Automated checks: 43 tests pass (8 game, 4 HTTP API, 13 authentication, 10 progression, 8 launch/support). Tests exercise actual SQLite migrations, queries and transactions. No production users or credentials are used.

Simulation coverage: 8,000 seeded balance matches and 10,000 matches across 100 persistent simulated careers. Checked result accounting, 1,000 season transitions, bounded ratings, finances, 11 unique shirt numbers, match settlement, concealed future results and bounded history. These are simulations, not 18,000 human/device play sessions.

Other coverage: registration, password hashing, normalized email, login/logout, expired sessions, recovery and code rotation, cross-account isolation, deletion, atomic duplicate purchases, offline cap, transfer validation, training caps, tactics, full round robin, missions/daily rollover, malformed JSON, contact persistence/consent/rate limiting, receipt, old support cleanup, marketing/native bundle separation and PNG artwork bytes.

Build verification: locally packaged Capacitor Android assets; compile/target SDK 36, minimum 24; debug APK and release AAB build. Release bundle has no production upload signature. The debug APK is for testing only.

Limitations: no managed browser QA tool was available. No device was connected. Emulator installation failed for lack of disk space while extracting Google's system image; temporary downloads were removed. Native UI, keyboard, TalkBack, font scaling, navigation/back, process recreation, network reconnection and the new document picker still require actual-device testing. No genuine device screenshots were captured. Website imagery is labelled promotional illustration/design preview.

Release blockers: owner's Play account verification and signing; internal device test and Play pre-launch report; real screenshots; audience/content rating/data safety/reviewer access declarations; required closed test if applicable; operational support inbox and email delivery if desired. External account-deletion requests require an ownership verification procedure. No claim of production launch or Google approval.

## 1.0.2 visual regression fix

A real user screenshot exposed missing inherited text colors and CSS variables in the Android login. The font-import stripping expression stopped at a semicolon inside the Google Fonts URL and invalidated the subsequent :root selector. Removal now consumes the complete import. A regression check verifies the packaged CSS begins with a valid root theme after bundled font faces, without an external font URL, and contains both text and lime colors. All 45 automated checks pass. Android APK/AAB rebuilt as versionCode 3; no physical-device visual verification performed in this environment.

## 1.0.3 release preparation

45 automated tests pass, including the existing native-theme regression and stricter multi-@ contact-address rejection. Build/asset checks verify version metadata, icon/feature-graphic dimensions, store title/short-description lengths, native/local settings, and exclusion of the support email and playable game from the public bundle. Error boundaries provide retry/support fallback instead of a blank view; expired mutation sessions return to login. Signing configuration now rejects partially supplied upload-key variables. All required dependency and font notices are bundled. The new UI behaviors still require device verification.

## 1.0.4 tycoon and account update

59 standard automated tests plus 3 browser-draft tests pass. New coverage checks sale values/academy replacements, impossible resale loops, match locks, concurrent sale idempotency, stadium thresholds, password changes/session and recovery rotation, disabled mail handling, hashed single-use tokens, email changes, expiry, reset privacy and reuse, recipient limits, provider errors, and durable support tickets during mail failure. Mail tests replace fetch with a simulated provider; no real mails are sent. No new device or browser UI session was available.

Latest 1.0.4 steering: personal recovery-code generation, UI, file export and API redemption removed. Registration/password changes return only the user/session; legacy codes are invalidated without deleting accounts or sessions. Tests now validate this behavior. The mail-reset tests confirm a single-use emailed code changes the password without issuing a permanent code. Android lint succeeded with warnings for template resources, icons, Gradle currency and synchronous preference persistence; no errors. Backup/transfer exclusions were subsequently made explicit.

## 1.1.0 management verification

77 standard automated tests plus 3 web-draft tests pass. Sixteen new management tests cover legacy normalization, four formations, goalkeeper constraints, bench capacity and sales, individual training/potential, coach effects and wages, timed academy/graduate idempotency, full benches, ticket/capacity math, supporter changes/campaign cooldown, cup eligibility/accounting/trophies/penalties/season reset and concurrent SQLite API requests. Two server-rendering tests check management views on legacy state and academy/cup result states; these are rendering checks, not browser interaction tests.

Additional simulation: 20 careers × 20 seasons = 4,000 league and 630 cup matches. In combination with the existing 8,000 balance and 10,000 long-career matches, 22,630 simulated matches run through test loops (plus focused cases). Accounts and saved club JSON are preserved. No live user accounts are modified by tests. Real Android UI and interactive browser QA remain outstanding.

## 1.2.0 arena, navigation and login

82 standard automated checks plus 3 web-draft checks pass (85 total). New coverage checks exact eight-character registration/login/password changes, rejects seven-character passwords, and exercises eight-character email reset using a fake mail provider. Mail is not configured in production. Four server-rendering checks cover club management, arena geometry at four stages, the email-only initial login screen and manager journey. Two mission tests cover all seven new milestones, legacy claims, progress limits and idempotent claims. Existing match simulations remain 22,630 matches.

The arena projects 3D world coordinates into SVG, sorts solid faces by depth, and uses memoization to avoid rebuilding unchanged geometry on the game clock. There is no WebGL or new native dependency. Its start/final SVG stages were rasterized and visually inspected with librsvg; this verifies arena artwork only. Full native layout, camera touch interaction, two-step login/autofill, mobile menu/back, font scaling and keyboard still need physical-device verification. No browser/device interaction test is claimed.

The APK and unsigned AAB were built for version 1.2.0 (7). APK embedded HTML was compared byte-for-byte to current local native assets. Existing test signing identity is retained. Web game remains an unpublished local draft.
