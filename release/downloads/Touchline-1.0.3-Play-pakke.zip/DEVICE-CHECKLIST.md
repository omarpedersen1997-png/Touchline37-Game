# Android test before Play rollout

Install the debug APK on a test phone (Android 7+). Use a new test account, not a personal account. Do not publish the debug APK as a production release.

- Create account, save recovery code through Android's document picker, cancel/retry the picker, copy code, acknowledge saved.
- Login after force-close; logout; wrong password; recover with saved code; old code/session must fail.
- Rename club; inspect all six tabs; buy a player; upgrade all buildings; change tactics.
- Start match, close match view, background/force-close and relaunch; result and reward should settle once.
- Disconnect/reconnect: display retry, retain account and saved club, no duplicate debit when retrying a purchase.
- Return after idle: income up to eight hours, no repeat credit on refresh.
- Play a season, inspect standings and promotion; claim mission once; inspect career counters.
- Open help/privacy/contact; submit a marked test message; save receipt; return with Android Back.
- Try keyboard, large fonts, small display, portrait/landscape, screen reader, gesture navigation and system bars.
- Delete test account with password + SLET; relaunch; login and old recovery code must fail.

Run Play internal testing and pre-launch report on the owner's signed AAB. Capture genuine screenshots for the store listing only after UI testing.
