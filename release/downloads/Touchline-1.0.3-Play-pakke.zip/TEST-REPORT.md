# Launch verification — 1.0.1

Automated checks: 43 tests pass (8 game, 4 HTTP API, 13 authentication, 10 progression, 8 launch/support). Tests exercise actual SQLite migrations, queries and transactions. No production users or credentials are used.

Simulation coverage: 8,000 seeded balance matches and 10,000 matches across 100 persistent simulated careers. Checked result accounting, 1,000 season transitions, bounded ratings, finances, 11 unique shirt numbers, match settlement, concealed future results and bounded history. These are simulations, not 18,000 human/device play sessions.

Other coverage: registration, password hashing, normalized email, login/logout, expired sessions, recovery and code rotation, cross-account isolation, deletion, atomic duplicate purchases, offline cap, transfer validation, training caps, tactics, full round robin, missions/daily rollover, malformed JSON, contact persistence/consent/rate limiting, receipt, old support cleanup, marketing/native bundle separation and PNG artwork bytes.

Build verification: locally packaged Capacitor Android assets; compile/target SDK 36, minimum 24; debug APK and release AAB build. Release bundle has no production upload signature. The debug APK is for testing only.

Limitations: no managed browser QA tool was available. No device was connected. Emulator installation failed for lack of disk space while extracting Google's system image; temporary downloads were removed. Native UI, keyboard, TalkBack, font scaling, navigation/back, process recreation, network reconnection and the new document picker still require actual-device testing. No genuine device screenshots were captured. Website imagery is labelled promotional illustration/design preview.

Release blockers: owner's Play account verification and signing; internal device test and Play pre-launch report; real screenshots; audience/content rating/data safety/reviewer access declarations; required closed test if applicable; operational support inbox and email delivery if desired. External account-deletion requests require an ownership verification procedure. No claim of production launch or Google approval.

## 1.0.2 visual regression fix

A real user screenshot exposed missing inherited text colors and CSS variables in the Android login. The font-import stripping expression stopped at a semicolon inside the Google Fonts URL and invalidated the subsequent :root selector. Removal now consumes the complete import. A regression check verifies the packaged CSS begins with a valid root theme after bundled font faces, without an external font URL, and contains both text and lime colors. All 45 automated checks pass. Android APK/AAB rebuilt as versionCode 3; no physical-device visual verification performed in this environment.

## 1.0.3 release preparation

45 automated tests pass, including the existing native-theme regression and stricter multi-@ contact-address rejection. Build/asset checks verify version metadata, icon/feature-graphic dimensions, store title/short-description lengths, native/local settings, and exclusion of the support email and playable game from the public bundle. Error boundaries provide retry/support fallback instead of a blank view; expired mutation sessions return to login. Signing configuration now rejects partially supplied upload-key variables. All required dependency and font notices are bundled. The new UI behaviors still require device verification.
