# Android test before Play rollout

Install the debug APK on a test phone (Android 7+). Use a new test account, not a personal account. Do not publish the debug APK as a production release.

- Create account, confirm immediate access with no personal recovery-code step.
- Login after force-close; logout; wrong password; reset via email after provider activation; old sessions must fail.
- Rename club; inspect all six tabs; buy a player; upgrade all buildings; change tactics.
- Start match, close match view, background/force-close and relaunch; result and reward should settle once.
- Disconnect/reconnect: display retry, retain account and saved club, no duplicate debit when retrying a purchase.
- Return after idle: income up to eight hours, no repeat credit on refresh.
- Play a season, inspect standings and promotion; claim mission once; inspect career counters.
- Open help/privacy/contact; submit a marked test message; save receipt; return with Android Back.
- Try keyboard, large fonts, small display, portrait/landscape, screen reader, gesture navigation and system bars.
- Delete test account with password + SLET; relaunch; login and old personal recovery-code route must fail.

Run Play internal testing and pre-launch report on the owner's signed AAB. Capture genuine screenshots for the store listing only after UI testing.

## 1.1.0 management scenarios

- Change all four formations, verify pitch positions, choose a substitute, and try to move a goalkeeper into an outfield slot (must be denied).
- Buy a player, confirm the replaced player is on the bench; sell a reserve and a starter, checking distinct effects.
- Train starter/reserve individually; check exact debit and potential cap.
- Start academy course, background/relaunch after completion, claim once, and test a full bench without losing the prospect.
- Hire each staff type; check wage/net-income breakdown and offline income; max level 5.
- Change ticket prices and confirm attendance/net previews; change during match must be denied. Run campaign once, check one-hour cooldown.
- Play 2 league games, complete cup rounds, check penalties and trophy. Cup games must not change league points or played count. Cup resets with league season; staff, youth and fans persist.
- Verify new sections with Android keyboard, screen reader, large font size and smallest supported phone display.
